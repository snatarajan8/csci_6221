// +build !ci
// +build !legacy

package app

/*
#cgo LDFLAGS: -framework Foundation -framework UserNotifications
*/
import "C"
